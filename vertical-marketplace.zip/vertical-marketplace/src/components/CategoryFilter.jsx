// src/components/CategoryFilter.jsx

import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const CategoryFilter = ({ categories, selectedCategory, onCategoryChange }) => {
  return (
    <div className="flex flex-wrap gap-3 mb-8">
      {categories.map(category => (
        <Button
          key={category.id}
          variant={selectedCategory === category.id ? "default" : "outline"}
          onClick={() => onCategoryChange(category.id)}
          className={`rounded-lg ${
            selectedCategory === category.id 
              ? 'bg-violet-600 hover:bg-violet-700' 
              : 'hover:border-violet-300'
          }`}
        >
          {category.name}
          <Badge variant="secondary" className="ml-2 bg-white/10">
            {category.count}
          </Badge>
        </Button>
      ))}
    </div>
  );
};

export default CategoryFilter;