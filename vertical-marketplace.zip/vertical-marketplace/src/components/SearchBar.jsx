// src/components/SearchBar.jsx

import React from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from 'lucide-react';

const SearchBar = () => {
  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white/10 backdrop-blur-xl rounded-xl p-4 border border-white/20">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input 
              className="w-full pl-10 py-6 bg-white/5 border-white/10 text-white placeholder:text-gray-300"
              placeholder="Search artisans, crafts, or categories..."
            />
          </div>
          <Button className="py-6 px-8 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white">
            Search
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;