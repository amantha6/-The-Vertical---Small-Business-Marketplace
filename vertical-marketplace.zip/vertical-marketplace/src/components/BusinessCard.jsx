// src/components/BusinessCard.jsx

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, Star, Verified, Clock, 
  Share2, ExternalLink, Bookmark, Shield, TrendingUp 
} from 'lucide-react';

const BusinessCard = ({ business }) => {
  const { 
    name, category, rating, reviews, description, 
    location, status, badges, hours, trending, verified 
  } = business;

  return (
    <Card className="border border-gray-100 hover:shadow-lg transition-shadow">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-gradient-to-br from-violet-100 to-indigo-100">
              {trending ? (
                <TrendingUp className="w-6 h-6 text-violet-600" />
              ) : (
                <Shield className="w-6 h-6 text-violet-600" />
              )}
            </div>
            <div>
              <CardTitle className="flex items-center gap-2">
                {name}
                {verified && (
                  <Verified className="w-5 h-5 text-blue-500" />
                )}
              </CardTitle>
              <CardDescription>{category}</CardDescription>
            </div>
          </div>
          <div className="flex gap-2">
            {badges.map((badge, index) => (
              <Badge 
                key={index} 
                className="bg-violet-100 text-violet-700"
              >
                {badge}
              </Badge>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2 text-gray-600">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{status}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{location.distance} miles</span>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <p className="text-gray-600 mb-6">{description}</p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center bg-amber-50 px-3 py-1 rounded-full">
              <Star className="w-4 h-4 text-amber-500 fill-current" />
              <span className="ml-1 font-medium text-amber-700">
                {rating}
              </span>
              <span className="text-amber-600 text-sm ml-1">
                ({reviews.length})
              </span>
            </div>
            <Badge variant="outline" className="border-violet-200">
              {hours}
            </Badge>
          </div>
          
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="border-gray-200">
              <Bookmark className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="outline" className="border-gray-200">
              <Share2 className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              className="bg-violet-600 hover:bg-violet-700 text-white"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BusinessCard;