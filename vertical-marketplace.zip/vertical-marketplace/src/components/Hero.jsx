// src/components/Hero.jsx

import React from 'react';
import SearchBar from './SearchBar';

const Hero = () => {
  return (
    <div className="bg-gradient-to-r from-violet-900 to-indigo-900 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 py-16 relative z-10">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-white mb-4">
          The Vertical
        </h1>
        <p className="text-xl text-center text-gray-200 mb-12">
          Discover Local Artisans and Craftspeople
        </p>
        <SearchBar />
      </div>
    </div>
  );
};

export default Hero;