// src/data/mockData.js

export const categories = [
  { id: 'all', name: 'All Categories', count: 248 },
  { id: 'crafts', name: 'Handmade Crafts', count: 84 },
  { id: 'food', name: 'Artisanal Food', count: 56 },
  { id: 'jewelry', name: 'Jewelry & Accessories', count: 42 },
  { id: 'home', name: 'Home & Decor', count: 38 },
  { id: 'wellness', name: 'Wellness & Beauty', count: 28 }
];

export const businesses = [
  {
    id: 1,
    name: "Wildflower Ceramics",
    category: "Handmade Crafts",
    rating: 4.9,
    reviews: Array(42).fill(1),
    description: "Handcrafted ceramic pieces including tableware, vases, and decorative items. Each piece is uniquely designed and expertly crafted in our Portland studio.",
    location: { 
      distance: "0.8",
      address: "123 Artisan Way",
      city: "Portland"
    },
    status: "Open Now",
    badges: ["Featured", "Local Artisan"],
    hours: "10 AM - 6 PM",
    trending: true,
    verified: true,
    contact: {
      phone: "(503) 555-0123",
      email: "hello@wildflowerceramics.com",
      instagram: "@wildflowerceramics"
    }
  },
  {
    id: 2,
    name: "Heritage Leather Works",
    category: "Handmade Crafts",
    rating: 4.8,
    reviews: Array(35).fill(1),
    description: "Traditional leather crafting workshop specializing in handmade bags, wallets, and accessories. Using premium materials and time-honored techniques.",
    location: { 
      distance: "1.2",
      address: "456 Craft Street",
      city: "Portland"
    },
    status: "Closes in 3h",
    badges: ["Top Rated", "Sustainable"],
    hours: "11 AM - 7 PM",
    trending: false,
    verified: true,
    contact: {
      phone: "(503) 555-0124",
      email: "info@heritageleather.com",
      instagram: "@heritageleatherpdx"
    }
  },
  {
    id: 3,
    name: "Sweet Bloom Bakery",
    category: "Artisanal Food",
    rating: 4.9,
    reviews: Array(89).fill(1),
    description: "Artisanal bakery offering handcrafted sourdough bread, pastries, and seasonal specialties. All products made from locally sourced organic ingredients.",
    location: { 
      distance: "0.5",
      address: "789 Market Lane",
      city: "Portland"
    },
    status: "Open Now",
    badges: ["Local Favorite", "Organic"],
    hours: "7 AM - 4 PM",
    trending: true,
    verified: true,
    contact: {
      phone: "(503) 555-0125",
      email: "hello@sweetbloom.com",
      instagram: "@sweetbloompdx"
    }
  },
  {
    id: 4,
    name: "Moonstone Jewelry",
    category: "Jewelry & Accessories",
    rating: 4.7,
    reviews: Array(28).fill(1),
    description: "Handcrafted jewelry featuring unique designs with precious and semi-precious stones. Custom pieces and workshops available.",
    location: { 
      distance: "1.5",
      address: "321 Design District",
      city: "Portland"
    },
    status: "By Appointment",
    badges: ["Custom Work", "Workshop"],
    hours: "12 PM - 8 PM",
    trending: false,
    verified: true,
    contact: {
      phone: "(503) 555-0126",
      email: "create@moonstonejewelry.com",
      instagram: "@moonstonejewelrypdx"
    }
  }
];

export const featuredCategories = [
  {
    id: 'crafts',
    name: 'Handmade Crafts',
    description: 'Discover unique handcrafted items',
    icon: 'Palette'
  },
  {
    id: 'food',
    name: 'Artisanal Food',
    description: 'Local food and beverages',
    icon: 'UtensilsCrossed'
  },
  {
    id: 'jewelry',
    name: 'Jewelry',
    description: 'Handcrafted accessories',
    icon: 'Gem'
  },
  {
    id: 'home',
    name: 'Home & Decor',
    description: 'Beautiful handmade pieces',
    icon: 'Home'
  }
];